#     Copyright 2020, Jorj McKie, mailto:<jorj.x.mckie@outlook.de> find license text at end of file


"""Deprecated eventlet plugin."""

from nuitka.plugins.PluginBase import NuitkaPluginBase


class NuitkaPluginEventlet(NuitkaPluginBase):
    """This plugin is now not doing anything anymore."""

    plugin_name = "eventlet"
    plugin_desc = "Deprecated, was once required by 'eventlet' package."
    plugin_category = "package-support,obsolete"

    @classmethod
    def isDeprecated(cls):
        return True


#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the GNU Affero General Public License, Version 3 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        https://www.gnu.org/licenses/agpl-3.0.txt
#
#     See also: "Nuitka Runtime Library Exception, Version 1.0" in file
#     "LICENSE-RUNTIME.txt" for additional permissions granted under Section 7.
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
