#     Copyright 2026, Kay Hayen, mailto:kay.hayen@gmail.com find license text at end of file


"""
This module handles the extraction of build configuration from Poetry projects.
"""

import os
import sys

from nuitka.importing.Importing import addMainScriptDirectory
from nuitka.utils.Execution import executeProcess
from nuitka.utils.FileOperations import withTemporaryDirectory
from nuitka.utils.Json import loadJsonFromFilename

from .BuildPackageCommon import applyNuitkaProjectOptions, reportBuildError


def getPoetryBuildConfiguration(logger, pyproject_data):
    """
    Get the build configuration from a Poetry project.
    """
    # This is "poetry" handling.
    with withTemporaryDirectory("nuitka-project-dump") as temp_dir:
        dump_filename = os.path.join(temp_dir, "build_config.json")

        # Locate the script "misc/extract-poetry-config.py" relative to this module.
        # We assume this module is in "nuitka/options/Poetry.py"
        script_filename = os.path.join(
            os.path.dirname(__file__),
            "..",
            "tools",
            "general",
            "extract_poetry_config",
        )

        command = (
            sys.executable,
            script_filename,
            dump_filename,
        )

        process_result = executeProcess(
            command,
            stdin=False,
        )

        if process_result.exit_code != 0:
            reportBuildError(
                logger=logger,
                name="poetry",
                command=command,
                stdout=process_result.stdout,
                stderr=process_result.stderr,
            )

        config = loadJsonFromFilename(dump_filename)

        package_dir = config.get("package_dir")
        if package_dir and "" in package_dir:
            addMainScriptDirectory(os.path.join(os.getcwd(), package_dir.get("")))
        else:
            addMainScriptDirectory(os.getcwd())

    arguments = config.get("arguments", [])
    project_name = config.get("project_name")
    if project_name:
        arguments.insert(0, "--project-name=%s" % project_name)
    else:
        return logger.sysexit("""\
Error, 'poetry' project has no 'name'. Set it in the '[project]' \
section of 'pyproject.toml'.""")

    # Apply options from [tool.nuitka] section of pyproject.toml
    arguments.extend(applyNuitkaProjectOptions(pyproject_data=pyproject_data))

    return arguments


#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the GNU Affero General Public License, Version 3 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        https://www.gnu.org/licenses/agpl-3.0.txt
#
#     See also: "Nuitka Runtime Library Exception, Version 1.0" in file
#     "LICENSE-RUNTIME.txt" for additional permissions granted under Section 7.
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
