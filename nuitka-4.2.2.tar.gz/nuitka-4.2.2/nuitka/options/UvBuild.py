#     Copyright 2026, Kay Hayen, mailto:kay.hayen@gmail.com find license text at end of file


"""
This module handles the extraction of build configuration from UV Build projects.
"""

import os
import sys

from nuitka.importing.Importing import addMainScriptDirectory
from nuitka.utils.Execution import executeProcess
from nuitka.utils.FileOperations import withTemporaryDirectory
from nuitka.utils.Json import loadJsonFromFilename

from .BuildPackageCommon import (
    applyNuitkaProjectOptions,
    reportBuildError,
    setProjectExpectedDataFiles,
)


def _maybeVirtualEnv(path):
    """
    Check if a directory might be a virtualenv.
    """
    # Windows
    if os.path.exists(os.path.join(path, "Scripts", "python.exe")):
        return True

    # Unix
    if os.path.exists(os.path.join(path, "bin", "python")):
        return True

    return False


def _handleUvConfig(logger, pyproject_data):
    uv_config = dict(pyproject_data.get("tool", {}).get("uv", {}))
    uv_build_config = dict(uv_config.pop("build-backend", {}))

    module_root = uv_build_config.pop("module-root", None)
    if module_root is not None:
        addMainScriptDirectory(os.path.abspath(module_root))
    elif os.path.exists("src"):
        addMainScriptDirectory(os.path.abspath("src"))
    else:
        addMainScriptDirectory(os.getcwd())

    if uv_build_config:
        for unhandled_key in uv_build_config:
            logger.warning(
                """\
Unhandled UV build backend config key '%s' in [tool.uv.build-backend] of the \
'pyproject.toml', we might have to ignore list or handle it: %s"""
                % (unhandled_key, uv_build_config[unhandled_key])
            )

    if uv_config:
        for unhandled_key in uv_config:
            logger.warning("""\
Unhandled UV config key '%s' in [tool.uv] of the 'pyproject.toml', we might \
have to ignore list or handle it: %s""" % (unhandled_key, uv_config[unhandled_key]))


def getUvBuildConfiguration(logger, pyproject_data):
    """
    Get the build configuration from a UV Build project.
    """

    # Necessarily a lot of details in the configuration

    with withTemporaryDirectory("nuitka-project-dump") as temp_dir:
        dump_filename = os.path.join(temp_dir, "build_config.json")

        # Locate the script "tools/general/extract_uv_config/__main__.py" relative to this module.
        # We assume this module is in "nuitka/options/UvBuild.py"
        script_filename = os.path.join(
            os.path.dirname(__file__),
            "..",
            "tools",
            "general",
            "extract_uv_config",
        )

        command = (
            sys.executable,
            script_filename,
            dump_filename,
        )

        process_result = executeProcess(
            command,
            stdin=False,
        )

        if process_result.exit_code != 0:
            reportBuildError(
                logger=logger,
                name="uv_build",
                command=command,
                stdout=process_result.stdout,
                stderr=process_result.stderr,
            )

        if not os.path.exists(dump_filename):
            return logger.sysexit(
                "Error, 'uv_build' configuration extraction produced no output file."
            )

        config = loadJsonFromFilename(dump_filename)

        arguments = config.get("arguments", [])

        _handleUvConfig(logger, pyproject_data)

        detected_packages = config.get("packages", [])

        # Add --include-package-data for detected packages
        # Only if not already specified by other means (though duplicate args are usually fine/merged)
        for package_name in detected_packages:
            arguments.append("--include-package-data=%s" % package_name)
            arguments.append("--include-package=%s" % package_name)

        setProjectExpectedDataFiles(config.get("data_files", []))

        project_name = config.get("project_name")
        if project_name:
            arguments.insert(0, "--project-name=%s" % project_name)
        else:
            return logger.sysexit("""\
Error, 'uv_build' project has no 'name'. Set it in the '[project]' \
section of 'pyproject.toml'.""")

        # Apply options from [tool.nuitka] section of pyproject.toml
        arguments.extend(applyNuitkaProjectOptions(pyproject_data=pyproject_data))

        # TODO: Check against IncludedDataFiles set once that is considered complete

        return arguments


#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the GNU Affero General Public License, Version 3 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        https://www.gnu.org/licenses/agpl-3.0.txt
#
#     See also: "Nuitka Runtime Library Exception, Version 1.0" in file
#     "LICENSE-RUNTIME.txt" for additional permissions granted under Section 7.
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
